from django.apps import AppConfig


class SubsConfig(AppConfig):
    name = 'subs'
